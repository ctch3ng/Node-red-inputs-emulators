/**
 * Copyright 2020 Ben Cheng
 *
 **/

module.exports = function(RED) {
   function buttonEmu(config) {
	RED.nodes.createNode(this,config);
	var node = this;	
	node.on('input',function(msg){	
		node.send(msg);
		setTimeout(function(){node.send(msg);},200+Math.floor(Math.random()*60));
	});
   }
   RED.nodes.registerType("button-emu", buttonEmu);
}