/**
 * Copyright 2015 Brendan Murray
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified into an emulator by Ben Cheng 2020-07-25
 **/

// Dependency - dht sensor package
//var sensorLib = require("node-dht-sensor");


module.exports = function(RED) {
   "use strict";

   // The main node definition - most things happen in here
   function dhtSensor(config) {

      // Create a RED node
      RED.nodes.createNode(this, config);

      // Store local copies of the node configuration (as defined in the .html)
      var node = this;

      this.topic = config.topic;
      this.dht   = config.dht;

      // Read the data & return a message object
      this.read = function(msgIn) {
         var msg = msgIn ? msgIn : {};
         var reading  = { temperature : Math.floor(Math.random()*30)+5, humidity : Math.floor(Math.random()*70)+30 };

         msg.payload  = reading.temperature.toFixed(2);
         msg.humidity = reading.humidity.toFixed(2);
         msg.isValid  = reading.isValid;
         msg.errors   = reading.errors;
         msg.topic    = node.topic || node.name;
         msg.location = node.name;
         msg.sensorid = 'dht' + node.dht + 'emu';

         return msg;
      };

      // respond to inputs....
      this.on('input', function (msg) {
         msg = this.read(msg);

         if (msg)
            node.send(msg);
      });

      var msg = this.read();

      // send out the message to the rest of the workspace.
      if (msg)
         this.send(msg);
   }

   // Register the node by name.
   RED.nodes.registerType("dht-emu", dhtSensor);
}